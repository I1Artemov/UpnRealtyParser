/// <reference types="react" />
import { Control } from 'leaflet';
export declare type ScaleControlProps = Control.ScaleOptions;
export declare const ScaleControl: import("react").ForwardRefExoticComponent<Control.ScaleOptions & import("react").RefAttributes<Control.Scale>>;
