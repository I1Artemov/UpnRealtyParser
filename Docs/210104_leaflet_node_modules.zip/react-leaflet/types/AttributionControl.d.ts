/// <reference types="react" />
import { Control } from 'leaflet';
export declare type AttributionControlProps = Control.AttributionOptions;
export declare const AttributionControl: import("react").ForwardRefExoticComponent<Control.AttributionOptions & import("react").RefAttributes<Control.Attribution>>;
