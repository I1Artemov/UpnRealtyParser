import { Map } from 'leaflet';
export declare function useAttribution(map: Map, attribution: string | null | undefined): void;
